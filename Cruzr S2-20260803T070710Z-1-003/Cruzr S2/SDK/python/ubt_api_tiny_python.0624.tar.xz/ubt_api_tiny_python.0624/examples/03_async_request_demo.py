#!/usr/bin/env python3
"""
Example 3: Async Request Demo
演示异步请求功能，包括无参数和带参数的请求
"""

import ubt_robot
import time


def main():
    print("== UbtApi Demo ==")
    
    # 创建 API 实例
    api = ubt_robot.Api()
    
    # 配置连接参数
    config = ubt_robot.Config()
    config.address = "0.0.0.0:51000"  # 指定机器人Api的服务地址
    config.api_id = "demo"               # 填入ApiId
    config.token = ""                     # 填入Token
    
    # 初始化和启动 API
    api.initialize(config)
    api.start()
    
    # 等待连接完成
    api.wait_until_connected()
    
    # 异步请求示例 (无参数)
    def on_subscribe_response(response):
        if not response.is_success:
            print(f"Subscribe fault error: code = {response.error_code}, message = {response.error_message}")
        else:
            print(f"Subscribe fault success: result = {response.result}")
    
    api.request("cc.api.fault.subscribe", on_subscribe_response)
    
    # 异步请求示例 (带参数)
    params = {
        "startIndex": 12,
        "endIndex": 13
    }
    
    def on_history_response(response):
        if not response.is_success:
            print(f"Get current fault error: code = {response.error_code}, message = {response.error_message}")
        else:
            print(f"Get current fault success: result = {response.result}")
    
    api.request("cc.api.fault.history.get_range", params, on_history_response)
    
    # 等待 3 秒钟以接收异步响应
    print("Waiting for async responses (3 seconds)...")
    time.sleep(3)
    
    # 停止 API 连接服务
    api.stop()
    
    print("== End ==")


if __name__ == "__main__":
    main()
