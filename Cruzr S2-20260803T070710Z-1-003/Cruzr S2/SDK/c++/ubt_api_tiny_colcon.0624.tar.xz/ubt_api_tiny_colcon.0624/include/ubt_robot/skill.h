#ifndef UBT_API_SKILL_H
#define UBT_API_SKILL_H

#include <string>
#include <memory>

#include <ubt_robot/api.h>
#include <ubt_robot/work.h>

namespace ubt::robot {

//! 技能类，用于启动技能
class Skill {
 public:
  using SkillCode = std::string;
  using Json = Work::Json;

  Skill(Api &api);

  //！ 启动技能，返回任务实例指针
  std::unique_ptr<Work> launch(const SkillCode &skill_code, const Json &js_params);

 private:
  Api &api_;
};

}

#endif // UBT_API_SKILL_H
