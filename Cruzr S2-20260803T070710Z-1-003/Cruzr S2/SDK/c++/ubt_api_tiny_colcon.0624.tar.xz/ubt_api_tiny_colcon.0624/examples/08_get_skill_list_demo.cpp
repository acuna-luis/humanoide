#include <iostream>
#include <ubt_robot/api.h>
#include <thread>

using namespace std;
int main()
{
  cout << "== UbtApi Demo ==" << endl;
  ubt::robot::Api ubt_api;

  ubt::robot::Api::Config cfg;
  cfg.address = "0.0.0.0:51000";  //!< 指定机器人Api的服务地址
  cfg.api_id = "demo";    //!< 填入ApiId
  cfg.token = "";         //!< 填入Token

  ubt_api.initialize(cfg);  //!< 初始化

  ubt_api.start();          //!< 启动Api，内部开始连接机器人服务
  ubt_api.waitUntilConnected(); //!< 等待连接完成

  auto rsp = ubt_api.requestSync("cc.api.skill.list");
  if (rsp.error.code == 0) {  //!< 如果没有异常，则打印返回内容
    cout << "Success, result:" << rsp.js_result.dump() << std::endl;
  } else {  //!< 如果错误，则打印错误码与错误信息
    cout << "Error, code:" << rsp.error.code << ", message:" << rsp.error.message << endl;
  }
  this_thread::sleep_for(chrono::seconds(3)); //!< 连接成功后，保持3秒钟
  ubt_api.stop(); //!< 停止Api连接服务

  cout << "== End ==" << endl;
  return 0;
}
