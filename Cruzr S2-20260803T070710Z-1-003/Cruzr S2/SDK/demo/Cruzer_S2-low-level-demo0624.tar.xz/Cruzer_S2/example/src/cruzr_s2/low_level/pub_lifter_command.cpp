#include <mc_task_msgs/msg/robot_command.hpp>
#include <mc_task_msgs/msg/joint_cmd.hpp>

#include <chrono>
#include <rclcpp/rclcpp.hpp>
#include <std_msgs/msg/header.hpp>
#include <cmath>
#include <algorithm>

int main(int argc, char **argv) {
  rclcpp::init(argc, argv);
  auto node = rclcpp::Node::make_shared("pub_lifter_command");
  auto cmd_publisher_ = node->create_publisher<mc_task_msgs::msg::RobotCommand>("/mc/sdk/robot_command", 10);
  rclcpp::Rate rate(500);
  double time_cnt = 0.0;
  
  while (rclcpp::ok()) {
    mc_task_msgs::msg::RobotCommand cmd;
    cmd.header.stamp = node->now();

    // 计算关节角度值，基于正弦函数
    double lifter_value = (1 - cos(time_cnt)) * 0.3;
    
    // 确保不越过0，限制在合理范围内
    double joint2_value = lifter_value;
    // 限制 joint2 的范围在 [0.0, 0.3] 之间
    joint2_value = std::clamp(joint2_value, 0.0, 0.6);
    
    // joint1 和 joint3 的和的绝对值等于 joint2 的值
    // 为了简单起见，我们可以让 joint1 和 joint3 相等
    double joint1_value = -joint2_value / 2.0;
    double joint3_value = -joint2_value / 2.0;
    
    // 确保所有关节值都不会越过0太多，设置合理的限位
    joint1_value = std::clamp(joint1_value, -0.3, 0.0);
    joint3_value = std::clamp(joint3_value, -0.3, 0.0);

    // 设置第一个关节
    mc_task_msgs::msg::JointCmd lifter_joint_1;
    lifter_joint_1.name = "lifter_pitch_1_joint";
    lifter_joint_1.control_mode = mc_task_msgs::msg::JointCmd::MODE_POSITION;
    lifter_joint_1.position = joint1_value;
    cmd.joint_cmd.push_back(lifter_joint_1);

    // 设置第二个关节
    mc_task_msgs::msg::JointCmd lifter_joint_2;
    lifter_joint_2.name = "lifter_pitch_2_joint";
    lifter_joint_2.control_mode = mc_task_msgs::msg::JointCmd::MODE_POSITION;
    lifter_joint_2.position = joint2_value;
    cmd.joint_cmd.push_back(lifter_joint_2);

    // 设置第三个关节
    mc_task_msgs::msg::JointCmd lifter_joint_3;
    lifter_joint_3.name = "lifter_pitch_3_joint";
    lifter_joint_3.control_mode = mc_task_msgs::msg::JointCmd::MODE_POSITION;
    lifter_joint_3.position = joint3_value;
    cmd.joint_cmd.push_back(lifter_joint_3);

    cmd_publisher_->publish(cmd);

    time_cnt += 0.002;
    rate.sleep();
  }
  
  rclcpp::shutdown();
  return EXIT_SUCCESS;
}