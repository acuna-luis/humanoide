// Copyright 2025 UBTECH. All rights reserved.
//
// Demo: 发布大寰(DH)夹爪控制指令 (ROS2 版本)
//
// 话题信息:
//   命令话题: /ecat/left_grip/cmd  (左夹爪)
//             /ecat/right_grip/cmd (右夹爪)
//   消息类型: ecat_task_msgs::msg::GripCmd
//
// GripCmd 字段说明:
//   header  - 消息头 (shm_msgs::msg::Header)
//   init    - 初始化标志 (uint16)
//   mode    - 运行模式 (uint16): 0=位置/力模式, 10=力推模式(仅气缸)
//   stop    - 停止标志 (uint16)
//   reset   - 复位标志 (uint16)
//   homing  - 回零标志 (uint16)
//   pos     - 目标位置 (double): [0 ~ 0.05] m
//   vel     - 目标速度 (double): [0 ~ 0.1] m/s
//   force   - 目标力   (double): [0 ~ 100] N
//   cur     - 目标电流 (double): [0 ~ 0.4] A

#include <chrono>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <memory>

#include <rclcpp/rclcpp.hpp>
#include <ecat_task_msgs/msg/grip_cmd.hpp>

using GripCmd = ecat_task_msgs::msg::GripCmd;

int main(int argc, char **argv) {
  rclcpp::init(argc, argv);
  auto node = rclcpp::Node::make_shared("pub_gripper_command");

  constexpr size_t kQueueSize = 10;

  // 创建左右夹爪的命令 Publisher
  auto left_grip_pub =
      node->create_publisher<GripCmd>("/ecat/left_grip/cmd", kQueueSize);
  auto right_grip_pub =
      node->create_publisher<GripCmd>("/ecat/right_grip/cmd", kQueueSize);

  // 默认参数
  constexpr double kDefaultVelocity = 0.1;   // m/s
  constexpr double kDefaultForce = 50.0;     // N
  constexpr double kDefaultCurrent = 0.2;    // A

  rclcpp::Rate rate(10);  // 10 Hz
  double time_cnt = 0.0;

  std::cout << "=== DH Gripper Command Publisher Demo (ROS2) ===" << std::endl;
  std::cout << "Publishing gripper commands to:" << std::endl;
  std::cout << "  Left:  /ecat/left_grip/cmd" << std::endl;
  std::cout << "  Right: /ecat/right_grip/cmd" << std::endl;
  std::cout << "Press Ctrl+C to stop." << std::endl;

  while (rclcpp::ok()) {
    // 构建左夹爪命令: 用正弦波在 [0, 0.05]m 范围内来回运动
    GripCmd left_cmd;
    auto now = node->get_clock()->now();
    left_cmd.header.stamp.sec = now.seconds();
    left_cmd.header.stamp.nanosec = now.nanoseconds() % 1000000000;
    left_cmd.pos = (std::sin(time_cnt) + 1.0) / 2.0 * 0.05;  // 映射到 [0, 0.05]
    left_cmd.vel = kDefaultVelocity;
    left_cmd.force = kDefaultForce;
    left_cmd.cur = kDefaultCurrent;
    left_cmd.mode = 0;  // 位置/力模式

    // 构建右夹爪命令: 与左夹爪反相
    GripCmd right_cmd;
    right_cmd.header.stamp.sec = now.seconds();
    right_cmd.header.stamp.nanosec = now.nanoseconds() % 1000000000;
    right_cmd.pos = (std::sin(time_cnt + M_PI) + 1.0) / 2.0 * 0.05;
    right_cmd.vel = kDefaultVelocity;
    right_cmd.force = kDefaultForce;
    right_cmd.cur = kDefaultCurrent;
    right_cmd.mode = 0;

    // 发布命令
    left_grip_pub->publish(left_cmd);
    right_grip_pub->publish(right_cmd);

    std::cout << "\r[t=" << std::fixed << std::setprecision(2) << time_cnt << "s] "
              << "L: " << std::setprecision(4) << left_cmd.pos << " m  "
              << "R: " << right_cmd.pos << " m    " << std::flush;

    time_cnt += 0.1;  // 与 10Hz 对应
    rate.sleep();
  }

  std::cout << std::endl;
  rclcpp::shutdown();
  return EXIT_SUCCESS;
}
