#include "rclcpp/rclcpp.hpp"
#include "sensor_msgs/msg/laser_scan.hpp"

class LidarFrontSubscriber : public rclcpp::Node
{
 public:
  LidarFrontSubscriber() : Node("lidar_front_subscriber")
  {
    subscription_ = this->create_subscription<sensor_msgs::msg::LaserScan>(
        "/sensor/lidar/front", rclcpp::QoS(rclcpp::KeepLast(10)).best_effort(),
        std::bind(&LidarFrontSubscriber::topic_callback, this,
                  std::placeholders::_1));
  }

 private:
  void topic_callback(const sensor_msgs::msg::LaserScan::SharedPtr msg)
  {
    RCLCPP_INFO(this->get_logger(), "Cruent Time: %d sec %u nanosec",
                msg->header.stamp.sec, msg->header.stamp.nanosec);
    RCLCPP_INFO(this->get_logger(), "Frame id: %s",
                msg->header.frame_id.c_str());
    RCLCPP_INFO(this->get_logger(), "Angle Min: %.3f rad; Angle Max: %.3f rad",
                msg->angle_min, msg->angle_max);
    RCLCPP_INFO(this->get_logger(), "Angle Increment: %.3f rad",
                msg->angle_increment);
    RCLCPP_INFO(this->get_logger(), "Time Increment: %.3f s",
                msg->time_increment);
    RCLCPP_INFO(this->get_logger(), "Scan Time: %.3f s", msg->scan_time);
    RCLCPP_INFO(this->get_logger(), "Range Min: %.3f m; Range Max: %.3f m",
                msg->range_min, msg->range_max);
  }

  rclcpp::Subscription<sensor_msgs::msg::LaserScan>::SharedPtr subscription_;
};

int main(int argc, char *argv[])
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<LidarFrontSubscriber>());
  rclcpp::shutdown();
  return 0;
}
