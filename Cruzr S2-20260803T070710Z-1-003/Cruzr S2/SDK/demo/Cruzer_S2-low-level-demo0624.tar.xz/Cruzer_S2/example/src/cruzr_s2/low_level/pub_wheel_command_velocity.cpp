#include <mc_task_msgs/msg/robot_command.hpp>
#include <mc_task_msgs/msg/joint_cmd.hpp>

#include <chrono>
#include <rclcpp/rclcpp.hpp>
#include <std_msgs/msg/header.hpp>
#include <cmath>

int main(int argc, char **argv) {
  rclcpp::init(argc, argv);
  auto node = rclcpp::Node::make_shared("pub_wheel_command_velocity");
  auto cmd_publisher_ = node->create_publisher<mc_task_msgs::msg::RobotCommand>("/mc/sdk/robot_command", 10);
  rclcpp::Rate rate(500);
  double time_cnt = 0.0;
  
  while (rclcpp::ok()) {
    mc_task_msgs::msg::RobotCommand cmd;
    cmd.header.stamp = node->now();

    // 左轮速度控制 - 逆时针方向
    mc_task_msgs::msg::JointCmd left_wheel;
    left_wheel.name = "driving_wheel_left_joint";
    left_wheel.control_mode = mc_task_msgs::msg::JointCmd::MODE_VELOCITY;
    left_wheel.velocity = 0.3; // 设置固定速度值，单位是弧度/s
    cmd.joint_cmd.push_back(left_wheel);

    // 右轮速度控制 - 顺时针方向（与左轮相反）
    mc_task_msgs::msg::JointCmd right_wheel;
    right_wheel.name = "driving_wheel_right_joint";
    right_wheel.control_mode = mc_task_msgs::msg::JointCmd::MODE_VELOCITY;
    right_wheel.velocity = -0.3; // 与左轮大小相同但方向相反
    cmd.joint_cmd.push_back(right_wheel);

    cmd_publisher_->publish(cmd);

    time_cnt += 0.002;
    rate.sleep();
  }
  
  rclcpp::shutdown();
  return EXIT_SUCCESS;
}